import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CmpOneComponent } from './cmp-one/cmp-one.component';
import { CmpTowComponent } from './cmp-tow/cmp-tow.component';
import { CmpThreeComponent } from './cmp-three/cmp-three.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
 
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {path:'home',component:HomeComponent},
  {path:'component-one',component:CmpOneComponent},
  {path:'component-two',component:CmpTowComponent},
  {path:'component-three/:id',component:CmpThreeComponent},
  {path:'**',component:PageNotFoundComponent},
]; //route table

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
