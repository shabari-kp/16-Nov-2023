import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpTowComponent } from './cmp-tow.component';

describe('CmpTowComponent', () => {
  let component: CmpTowComponent;
  let fixture: ComponentFixture<CmpTowComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CmpTowComponent]
    });
    fixture = TestBed.createComponent(CmpTowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
