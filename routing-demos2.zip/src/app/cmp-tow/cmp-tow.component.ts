import { Component } from '@angular/core';

@Component({
  selector: 'app-cmp-tow',
  templateUrl: './cmp-tow.component.html',
  styleUrls: ['./cmp-tow.component.css']
})
export class CmpTowComponent {

}
