import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-cmp-three',
  templateUrl: './cmp-three.component.html',
  styleUrls: ['./cmp-three.component.css']
})
export class CmpThreeComponent {
    id:any;
    sub:any;
  constructor(private route: ActivatedRoute) {}
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
    });
  }
}
