import { Component } from '@angular/core';

@Component({
  selector: 'app-cmp-two',
  templateUrl: './cmp-two.component.html',
  styleUrls: ['./cmp-two.component.css']
})
export class CmpTwoComponent {

}
