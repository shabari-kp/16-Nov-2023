import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpTwoComponent } from './cmp-two.component';

describe('CmpTwoComponent', () => {
  let component: CmpTwoComponent;
  let fixture: ComponentFixture<CmpTwoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CmpTwoComponent]
    });
    fixture = TestBed.createComponent(CmpTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
