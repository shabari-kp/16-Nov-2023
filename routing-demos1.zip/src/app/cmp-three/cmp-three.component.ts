import { Component } from '@angular/core';

@Component({
  selector: 'app-cmp-three',
  templateUrl: './cmp-three.component.html',
  styleUrls: ['./cmp-three.component.css']
})
export class CmpThreeComponent {

}
